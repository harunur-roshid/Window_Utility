For more details of configuration - https://learn.microsoft.com/en-us/office/ltsc/preview/install-ltsc-preview

open cmd as administrator and go to the directory
run the command: .\setup.exe /configure office2024_configuration.xml